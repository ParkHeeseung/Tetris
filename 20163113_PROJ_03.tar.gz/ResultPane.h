#include "Pane.h"

#ifndef __ResultPane_h__
#define __ResultPane_h__


class ResultPane : public Pane
{

  public:
  ResultPane(int x, int y, int w, int h);
  ResultPane();
  void draw();

};

#endif
