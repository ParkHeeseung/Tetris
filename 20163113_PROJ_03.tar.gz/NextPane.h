#include "Pane.h"

#ifndef __NextPane_h__
#define __NextPane_h__

class NextPane : public Pane {
public:
  NextPane(int x, int y, int w, int h);
  void draw();
};

#endif //__NextPane_h__
